class CalcController {

    /*
    *  CONSTRUTOR
    */

    constructor(){
        
        this._locale = 'pt-BR';
        this._displayCalcEl = document.querySelector("#display");
        this._dateEl = document.querySelector("#data");
        this._timeEl = document.querySelector("#hora");
        this._currentDate;
        this.initialize();

    }


    /* 
    *  MÉTODOS = "Funções"
    */

    initialize(){

        this.setDisplayDateTime();

        setInterval(()=>{

            this.setDisplayDateTime();

        }, 1000);

    }
    
    setDisplayDateTime(){

        this.displayDate = this.currentDate.toLocaleDateString(this._locale, {

            // Personalizando a Data
            // day: "2-digit", -> dia em dois dígitos
            // month: "long", -> mês por extenso
            // year: "numeric" -> ano em números
        });
        this.displayTime = this.currentDate.toLocaleTimeString(this._locale);

    }

    /*
    *  GETTER E SETTER
    *  Get -> Retorna o Valor
    *  Set -> Atribui o Valor
    */

    // Hora
    get displayTime() {

        return this._timeEl.innerHTML

    }

    set displayTime(value) {

        this._timeEl.innerHTML = value

    }

    // Data
    get displayDate(){

        return this._dateEl.innerHTML;

    }

    set displayDate(value) {

        this._dateEl.innerHTML = value

    }

    // Display
    get displayCalc(){

        return this._displayCalcEl.innerHTML;

    }
    
    set displayCalc(value){

        this._displayCalcEl.innerHTML = value;

    }

    // Data Atual
    get currentDate(){

        return new Date();

    }

    set currentDate(value){

        this._currentDate = value;

    }

}